import asyncio
import logging
import random
from collections import Counter
from dataclasses import dataclass, field
from typing import Optional

from aiogram import Bot, F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

import config as cfg
import database as db
from locales import t
from utils import esc

router = Router()
GROUP = F.chat.type.in_({"group", "supergroup"})
games: dict = {}


@dataclass
class Game:
    chat_id: int
    host: int
    lang: str
    players: dict = field(default_factory=dict)   # uid -> name
    roles: dict = field(default_factory=dict)     # uid -> role
    alive: set = field(default_factory=set)
    state: str = "lobby"
    kills: dict = field(default_factory=dict)     # mafia uid -> target
    heal: Optional[int] = None
    checked: bool = False
    votes: dict = field(default_factory=dict)
    event: asyncio.Event = field(default_factory=asyncio.Event)
    task: Optional[asyncio.Task] = None


def kb(rows):
    return InlineKeyboardMarkup(inline_keyboard=rows)


def lobby_text(g: Game):
    players = "\n".join(f"{i}. {esc(n)}" for i, n in enumerate(g.players.values(), 1))
    return t(g.lang, "lobby", host=esc(g.players[g.host]), n=len(g.players),
             players=players, min=cfg.MIN_PLAYERS)


def lobby_kb(lang):
    return kb([[InlineKeyboardButton(text=t(lang, "b_join"), callback_data="g:join"),
                InlineKeyboardButton(text=t(lang, "b_start"), callback_data="g:start")]])


# ---------------- lobby ----------------
@router.message(Command("game"), GROUP)
async def new_game(m: Message, bot: Bot):
    u = await db.get_user(m.from_user.id)
    if not u:
        me = await bot.me()
        return await m.reply(t("uz", "need_bot", bot=me.username))
    if m.chat.id in games:
        return await m.reply(t(u["lang"], "game_exists"))
    g = Game(m.chat.id, m.from_user.id, u["lang"])
    g.players[m.from_user.id] = m.from_user.full_name
    games[m.chat.id] = g
    await m.answer(lobby_text(g), reply_markup=lobby_kb(g.lang))


@router.callback_query(F.data == "g:join")
async def join(c: CallbackQuery, bot: Bot):
    g = games.get(c.message.chat.id)
    if not g or g.state != "lobby":
        return await c.answer("❌", show_alert=True)
    uid = c.from_user.id
    u = await db.get_user(uid)
    if not u:
        me = await bot.me()
        return await c.answer(t(g.lang, "need_bot", bot=me.username), show_alert=True)
    if uid in g.players:
        return await c.answer(t(u["lang"], "already"))
    if len(g.players) >= cfg.MAX_PLAYERS:
        return await c.answer("❌", show_alert=True)
    g.players[uid] = c.from_user.full_name
    await c.answer(t(u["lang"], "joined"))
    try:
        await c.message.edit_text(lobby_text(g), reply_markup=lobby_kb(g.lang))
    except Exception:
        pass


@router.callback_query(F.data == "g:start")
async def start_game(c: CallbackQuery, bot: Bot):
    g = games.get(c.message.chat.id)
    if not g or g.state != "lobby":
        return await c.answer("❌", show_alert=True)
    if c.from_user.id != g.host and c.from_user.id not in cfg.ADMIN_IDS:
        return await c.answer(t(g.lang, "no_perm"), show_alert=True)
    if len(g.players) < cfg.MIN_PLAYERS:
        return await c.answer(t(g.lang, "min_players", min=cfg.MIN_PLAYERS), show_alert=True)

    g.state = "starting"
    ids = list(g.players)
    random.shuffle(ids)
    n = len(ids)
    roles = ["mafia"] * max(1, n // 4)
    if n >= 5:
        roles.append("doctor")
    if n >= 6:
        roles.append("sheriff")
    roles += ["civilian"] * (n - len(roles))
    g.roles = dict(zip(ids, roles))
    team = ", ".join(esc(g.players[u]) for u in ids if g.roles[u] == "mafia")

    failed = []
    for uid in ids:
        lang = await db.get_lang(uid)
        try:
            await bot.send_message(uid, t(lang, "role_" + g.roles[uid], team=team))
        except Exception:
            failed.append(esc(g.players[uid]))
    try:
        await c.message.edit_reply_markup(reply_markup=None)
    except Exception:
        pass
    if failed:
        games.pop(g.chat_id, None)
        await c.message.answer(t(g.lang, "dm_failed", names=", ".join(failed)))
        return await c.answer()

    g.alive = set(ids)
    g.task = asyncio.create_task(run_game(bot, g))
    await c.answer()


@router.message(Command("stop"), GROUP)
async def stop(m: Message):
    g = games.get(m.chat.id)
    if not g:
        return await m.reply(t("uz", "no_game"))
    if m.from_user.id != g.host and m.from_user.id not in cfg.ADMIN_IDS:
        return await m.reply(t(g.lang, "no_perm"))
    if g.task:
        g.task.cancel()
    games.pop(m.chat.id, None)
    await m.reply(t(g.lang, "stopped"))


# ---------------- game loop ----------------
def winner(g: Game):
    m = sum(1 for u in g.alive if g.roles[u] == "mafia")
    c = len(g.alive) - m
    if m == 0:
        return "civ"
    if m >= c:
        return "mafia"
    return None


def night_complete(g: Game):
    if any(u not in g.kills for u in g.alive if g.roles[u] == "mafia"):
        return False
    if any(g.roles[u] == "doctor" for u in g.alive) and g.heal is None:
        return False
    if any(g.roles[u] == "sheriff" for u in g.alive) and not g.checked:
        return False
    return True


async def night(bot: Bot, g: Game):
    g.state = "night"
    g.kills, g.heal, g.checked = {}, None, False
    g.event = asyncio.Event()
    await bot.send_message(g.chat_id, t(g.lang, "night", s=cfg.NIGHT_SECONDS))
    for uid in g.alive:
        role = g.roles[uid]
        if role == "mafia":
            targets = [x for x in g.alive if g.roles[x] != "mafia"]
            key, code = "pick_kill", "k"
        elif role == "doctor":
            targets, key, code = list(g.alive), "pick_heal", "h"
        elif role == "sheriff":
            targets = [x for x in g.alive if x != uid]
            key, code = "pick_check", "c"
        else:
            continue
        rows = [[InlineKeyboardButton(text=g.players[x], callback_data=f"n:{code}:{g.chat_id}:{x}")]
                for x in targets]
        try:
            await bot.send_message(uid, t(await db.get_lang(uid), key), reply_markup=kb(rows))
        except Exception:
            pass
    if night_complete(g):
        g.event.set()
    try:
        await asyncio.wait_for(g.event.wait(), cfg.NIGHT_SECONDS)
    except asyncio.TimeoutError:
        pass
    g.state = "resolving"

    victim = None
    if g.kills:
        cnt = Counter(g.kills.values())
        top = max(cnt.values())
        victim = random.choice([k for k, v in cnt.items() if v == top])
    if victim is None:
        text = t(g.lang, "quiet")
    elif victim == g.heal:
        text = t(g.lang, "saved")
    else:
        g.alive.discard(victim)
        text = t(g.lang, "killed", name=esc(g.players[victim]))
    await bot.send_message(g.chat_id, text)


@router.callback_query(F.data.startswith("n:"), F.message.chat.type == "private")
async def night_cb(c: CallbackQuery):
    _, code, cid, target = c.data.split(":")
    g = games.get(int(cid))
    target, uid = int(target), c.from_user.id
    need = {"k": "mafia", "h": "doctor", "c": "sheriff"}[code]
    if (not g or g.state != "night" or uid not in g.alive or target not in g.alive
            or g.roles.get(uid) != need):
        return await c.answer("❌", show_alert=True)
    lang = await db.get_lang(uid)
    name = esc(g.players[target])
    if code == "k":
        if uid in g.kills:
            return await c.answer("❌")
        g.kills[uid] = target
    elif code == "h":
        if g.heal is not None:
            return await c.answer("❌")
        g.heal = target
    else:
        if g.checked:
            return await c.answer("❌")
        g.checked = True
    await c.message.edit_text(t(lang, "chosen", name=name))
    if code == "c":
        key = "check_mafia" if g.roles[target] == "mafia" else "check_civ"
        await c.message.answer(t(lang, key, name=name))
    if night_complete(g):
        g.event.set()
    await c.answer()


async def day(bot: Bot, g: Game):
    g.state = "day"
    alive = ", ".join(esc(g.players[u]) for u in g.alive)
    await bot.send_message(g.chat_id, t(g.lang, "day", s=cfg.DAY_SECONDS, alive=alive))
    await asyncio.sleep(cfg.DAY_SECONDS)

    g.state, g.votes, g.event = "vote", {}, asyncio.Event()
    rows = [[InlineKeyboardButton(text=g.players[x], callback_data=f"v:{x}")] for x in g.alive]
    msg = await bot.send_message(g.chat_id, t(g.lang, "vote_start", s=cfg.VOTE_SECONDS), reply_markup=kb(rows))
    try:
        await asyncio.wait_for(g.event.wait(), cfg.VOTE_SECONDS)
    except asyncio.TimeoutError:
        pass
    g.state = "resolving"
    try:
        await msg.edit_reply_markup(reply_markup=None)
    except Exception:
        pass

    cnt = Counter(g.votes.values())
    if cnt:
        top = max(cnt.values())
        leaders = [k for k, v in cnt.items() if v == top]
    else:
        leaders = []
    if len(leaders) == 1:
        out = leaders[0]
        g.alive.discard(out)
        text = t(g.lang, "lynched", name=esc(g.players[out]), role=t(g.lang, "r_" + g.roles[out]))
    else:
        text = t(g.lang, "no_lynch")
    await bot.send_message(g.chat_id, text)


@router.callback_query(F.data.startswith("v:"), F.message.chat.type.in_({"group", "supergroup"}))
async def vote_cb(c: CallbackQuery):
    g = games.get(c.message.chat.id)
    target, uid = int(c.data[2:]), c.from_user.id
    if (not g or g.state != "vote" or uid not in g.alive or uid in g.votes or target not in g.alive):
        return await c.answer("❌", show_alert=True)
    g.votes[uid] = target
    await c.answer(t(g.lang, "voted"))
    if len(g.votes) >= len(g.alive):
        g.event.set()


async def finish(bot: Bot, g: Game, w: str):
    mafia_won = w == "mafia"
    reveal = "\n".join(f"{esc(g.players[u])} — {t(g.lang, 'r_' + r)}" for u, r in g.roles.items())
    key = "win_mafia" if mafia_won else "win_civ"
    await bot.send_message(g.chat_id, t(g.lang, key, d=cfg.WIN_DIAMONDS) + "\n\n" + reveal)
    for uid, r in g.roles.items():
        won = (r == "mafia") == mafia_won
        await db.game_result(uid, won, cfg.WIN_DIAMONDS if won else 0)


async def run_game(bot: Bot, g: Game):
    try:
        while True:
            await night(bot, g)
            w = winner(g)
            if not w:
                await day(bot, g)
                w = winner(g)
            if w:
                await finish(bot, g, w)
                break
    except asyncio.CancelledError:
        raise
    except Exception:
        logging.exception("O'yin xatosi chat=%s", g.chat_id)
        try:
            await bot.send_message(g.chat_id, "⚠️ Error. /game")
        except Exception:
            pass
    finally:
        games.pop(g.chat_id, None)
