from aiogram import Bot, F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import (CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup,
                           KeyboardButton, Message, ReplyKeyboardMarkup)

import database as db
from locales import LANGS, all_t, t
from utils import esc

router = Router()
PRIVATE = F.chat.type == "private"


def menu_kb(lang):
    b = lambda k: KeyboardButton(text=t(lang, k))
    return ReplyKeyboardMarkup(keyboard=[[b("b_profile"), b("b_shop")], [b("b_lang"), b("b_help")]],
                               resize_keyboard=True)


def lang_kb():
    items = list(LANGS.items())
    rows = [[InlineKeyboardButton(text=n, callback_data=f"lang:{c}") for c, n in items[i:i + 2]]
            for i in range(0, len(items), 2)]
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def send_welcome(msg: Message, user, bot: Bot, lang):
    me = await bot.me()
    add = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(
        text="➕ Guruhga qo'shish", url=f"https://t.me/{me.username}?startgroup=true")]])
    await msg.answer(t(lang, "welcome", name=esc(user.full_name)), reply_markup=add)
    await msg.answer("👇", reply_markup=menu_kb(lang))


@router.message(CommandStart(), PRIVATE)
async def start(m: Message, state: FSMContext, bot: Bot):
    await state.clear()
    u = await db.get_user(m.from_user.id)
    if not u:
        await db.add_user(m.from_user.id, m.from_user.full_name)
        return await m.answer(t("uz", "choose_lang"), reply_markup=lang_kb())
    await db.add_user(m.from_user.id, m.from_user.full_name)
    await send_welcome(m, m.from_user, bot, u["lang"])


@router.callback_query(F.data.startswith("lang:"))
async def set_lang(c: CallbackQuery, bot: Bot):
    code = c.data.split(":")[1]
    if code not in LANGS:
        return await c.answer()
    await db.add_user(c.from_user.id, c.from_user.full_name)
    await db.set_lang(c.from_user.id, code)
    try:
        await c.message.delete()
    except Exception:
        pass
    await send_welcome(c.message, c.from_user, bot, code)
    await c.answer(t(code, "lang_set"))


@router.message(Command("cancel"), PRIVATE)
async def cancel(m: Message, state: FSMContext):
    await state.clear()
    await m.answer(t(await db.get_lang(m.from_user.id), "cancelled"))


@router.message(F.text.in_(all_t("b_profile")), PRIVATE)
async def profile(m: Message, state: FSMContext):
    await state.clear()
    u = await db.get_user(m.from_user.id)
    if not u:
        return await start(m, state, m.bot)
    await m.answer(t(u["lang"], "profile", name=esc(u["name"] or ""), id=u["id"],
                     d=u["diamonds"], g=u["games"], w=u["wins"]))


@router.message(F.text.in_(all_t("b_help")), PRIVATE)
async def help_(m: Message, state: FSMContext):
    await state.clear()
    await m.answer(t(await db.get_lang(m.from_user.id), "help"))


@router.message(F.text.in_(all_t("b_lang")), PRIVATE)
async def change_lang(m: Message, state: FSMContext):
    await state.clear()
    await m.answer(t(await db.get_lang(m.from_user.id), "choose_lang"), reply_markup=lang_kb())
