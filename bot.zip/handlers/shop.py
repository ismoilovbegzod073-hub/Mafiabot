from aiogram import Bot, F, Router
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

import database as db
from locales import all_t, t
from utils import esc, notify_admins, order_kb

router = Router()
PRIVATE = F.chat.type == "private"
MAX_AMOUNT = 100000


class Shop(StatesGroup):
    buy_amount = State()
    buy_receipt = State()
    sell_amount = State()
    sell_card = State()


def parse_amount(text):
    text = (text or "").strip()
    if text.isdigit() and 0 < int(text) <= MAX_AMOUNT:
        return int(text)
    return None


@router.message(F.text.in_(all_t("b_shop")), PRIVATE)
async def shop(m: Message, state: FSMContext):
    await state.clear()
    u = await db.get_user(m.from_user.id)
    if not u:
        return
    lang = u["lang"]
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=t(lang, "b_buy"), callback_data="shop:buy")],
        [InlineKeyboardButton(text=t(lang, "b_sell"), callback_data="shop:sell")]])
    await m.answer(t(lang, "shop", buy=await db.get_setting("buy_price"),
                     sell=await db.get_setting("sell_price"), d=u["diamonds"]), reply_markup=kb)


@router.callback_query(F.data == "shop:buy")
async def buy(c: CallbackQuery, state: FSMContext):
    await state.set_state(Shop.buy_amount)
    await c.message.answer(t(await db.get_lang(c.from_user.id), "buy_amount"))
    await c.answer()


@router.callback_query(F.data == "shop:sell")
async def sell(c: CallbackQuery, state: FSMContext):
    u = await db.get_user(c.from_user.id)
    await state.set_state(Shop.sell_amount)
    await c.message.answer(t(u["lang"], "sell_amount", d=u["diamonds"]))
    await c.answer()


# ---------- SOTIB OLISH ----------
@router.message(Shop.buy_amount, PRIVATE)
async def buy_amount(m: Message, state: FSMContext):
    lang = await db.get_lang(m.from_user.id)
    n = parse_amount(m.text)
    if not n:
        return await m.answer(t(lang, "invalid"))
    total = n * int(await db.get_setting("buy_price"))
    await state.update_data(amount=n, total=total)
    await state.set_state(Shop.buy_receipt)
    await m.answer(t(lang, "buy_pay", total=total, card=esc(await db.get_setting("card"))))


@router.message(Shop.buy_receipt, F.photo, PRIVATE)
async def buy_receipt(m: Message, state: FSMContext, bot: Bot):
    lang = await db.get_lang(m.from_user.id)
    data = await state.get_data()
    file_id = m.photo[-1].file_id
    oid = await db.create_order(m.from_user.id, "buy", data["amount"], data["total"], file_id)
    await state.clear()
    await m.answer(t(lang, "buy_sent", id=oid))
    await notify_admins(
        bot, f"🛒 Buyurtma #{oid} (SOTIB OLISH)\n👤 {esc(m.from_user.full_name)} "
             f"(<code>{m.from_user.id}</code>)\n💎 {data['amount']} | 💵 {data['total']} UZS",
        photo=file_id, kb=order_kb(oid))


@router.message(Shop.buy_receipt, PRIVATE)
async def buy_receipt_bad(m: Message):
    await m.answer(t(await db.get_lang(m.from_user.id), "send_photo"))


# ---------- SOTISH ----------
@router.message(Shop.sell_amount, PRIVATE)
async def sell_amount(m: Message, state: FSMContext):
    u = await db.get_user(m.from_user.id)
    n = parse_amount(m.text)
    if not n:
        return await m.answer(t(u["lang"], "invalid"))
    if n > u["diamonds"]:
        return await m.answer(t(u["lang"], "not_enough"))
    total = n * int(await db.get_setting("sell_price"))
    await state.update_data(amount=n, total=total)
    await state.set_state(Shop.sell_card)
    await m.answer(t(u["lang"], "sell_card", total=total))


@router.message(Shop.sell_card, F.text, PRIVATE)
async def sell_card(m: Message, state: FSMContext, bot: Bot):
    lang = await db.get_lang(m.from_user.id)
    card = m.text.strip()
    if not (8 <= len(card) <= 40):
        return await m.answer(t(lang, "invalid"))
    data = await state.get_data()
    if not await db.take_diamonds(m.from_user.id, data["amount"]):
        await state.clear()
        return await m.answer(t(lang, "not_enough"))
    oid = await db.create_order(m.from_user.id, "sell", data["amount"], data["total"], card)
    await state.clear()
    await m.answer(t(lang, "sell_sent", id=oid, amount=data["amount"]))
    await notify_admins(
        bot, f"💰 Buyurtma #{oid} (SOTISH)\n👤 {esc(m.from_user.full_name)} "
             f"(<code>{m.from_user.id}</code>)\n💎 {data['amount']} | 💵 {data['total']} UZS\n"
             f"💳 <code>{esc(card)}</code>", kb=order_kb(oid))
