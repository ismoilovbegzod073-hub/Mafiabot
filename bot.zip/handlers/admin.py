import asyncio

from aiogram import Bot, F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message

import database as db
from config import ADMIN_IDS
from locales import t
from utils import esc, order_kb

router = Router()
router.message.filter(F.from_user.id.in_(ADMIN_IDS))
router.callback_query.filter(F.from_user.id.in_(ADMIN_IDS))


class A(StatesGroup):
    broadcast = State()
    give = State()
    take = State()
    ban = State()
    unban = State()
    buy_price = State()
    sell_price = State()
    card = State()


PROMPTS = {
    "broadcast": "📢 Yuboriladigan xabarni yuboring (matn/rasm/video):",
    "give": "💎 Almaz berish. Format: <code>user_id miqdor</code>",
    "take": "➖ Almaz olish. Format: <code>user_id miqdor</code>",
    "ban": "🚫 Ban qilinadigan <code>user_id</code> ni yuboring:",
    "unban": "✅ Bandan chiqariladigan <code>user_id</code> ni yuboring:",
    "buy_price": "💰 1 almazni SOTIB OLISH narxi (UZS), faqat son:",
    "sell_price": "💵 1 almazni SOTISH narxi (UZS), faqat son:",
    "card": "💳 To'lov uchun karta raqami va egasi (matn):",
}


def panel_kb():
    b = lambda text, d: InlineKeyboardButton(text=text, callback_data=f"adm:{d}")
    return InlineKeyboardMarkup(inline_keyboard=[
        [b("📊 Statistika", "stats"), b("📋 Buyurtmalar", "orders")],
        [b("💎 Almaz berish", "give"), b("➖ Almaz olish", "take")],
        [b("📢 Xabar yuborish", "broadcast")],
        [b("🚫 Ban", "ban"), b("✅ Unban", "unban")],
        [b("💰 Sotib olish narxi", "buy_price"), b("💵 Sotish narxi", "sell_price")],
        [b("💳 Karta raqami", "card")],
    ])


@router.message(Command("admin"), F.chat.type == "private")
async def admin_panel(m: Message, state: FSMContext):
    await state.clear()
    await m.answer("🛠 <b>Admin panel</b>", reply_markup=panel_kb())


@router.callback_query(F.data.startswith("adm:"))
async def adm_cb(c: CallbackQuery, state: FSMContext, bot: Bot):
    act = c.data[4:]
    if act == "stats":
        u, pending = await db.stats()
        await c.message.answer(
            f"📊 <b>Statistika</b>\n👥 Foydalanuvchilar: {u['c']}\n🚫 Banlangan: {u['b']}\n"
            f"💎 Jami almaz: {u['d']}\n🎮 O'yinlar (yig'indi): {u['g']}\n📋 Kutilayotgan buyurtmalar: {pending}\n"
            f"💰 Sotib olish: {await db.get_setting('buy_price')} UZS | "
            f"💵 Sotish: {await db.get_setting('sell_price')} UZS")
    elif act == "orders":
        orders = await db.pending_orders()
        if not orders:
            await c.message.answer("📭 Kutilayotgan buyurtma yo'q.")
        for o in orders:
            kind = "SOTIB OLISH" if o["kind"] == "buy" else "SOTISH"
            text = (f"#{o['id']} ({kind})\n👤 <code>{o['user_id']}</code>\n"
                    f"💎 {o['amount']} | 💵 {o['total']} UZS")
            if o["kind"] == "buy":
                await bot.send_photo(c.from_user.id, o["details"], caption=text, reply_markup=order_kb(o["id"]))
            else:
                await c.message.answer(text + f"\n💳 <code>{esc(o['details'])}</code>",
                                       reply_markup=order_kb(o["id"]))
    elif act in PROMPTS:
        await state.set_state(getattr(A, act))
        await c.message.answer(PROMPTS[act])
    await c.answer()


@router.callback_query(F.data.startswith("ord:"))
async def order_cb(c: CallbackQuery, bot: Bot):
    _, act, oid = c.data.split(":")
    oid = int(oid)
    o = await db.get_order(oid)
    if not o:
        return await c.answer("Topilmadi", show_alert=True)
    status = "approved" if act == "ok" else "rejected"
    if not await db.claim_order(oid, status):
        return await c.answer("Allaqachon ko'rib chiqilgan", show_alert=True)
    if act == "ok" and o["kind"] == "buy":
        await db.add_diamonds(o["user_id"], o["amount"])
    if act == "no" and o["kind"] == "sell":
        await db.add_diamonds(o["user_id"], o["amount"])  # band qilingan almaz qaytariladi
    lang = await db.get_lang(o["user_id"])
    try:
        await bot.send_message(o["user_id"], t(lang, status, id=oid))
    except Exception:
        pass
    try:
        await c.message.edit_reply_markup(reply_markup=None)
    except Exception:
        pass
    await c.message.reply(f"#{oid}: {'✅ tasdiqlandi' if act == 'ok' else '❌ rad etildi'}")
    await c.answer()


# ---------- kiritish holatlari ----------
@router.message(A.broadcast)
async def do_broadcast(m: Message, state: FSMContext, bot: Bot):
    await state.clear()
    ids = await db.all_user_ids()
    ok = 0
    await m.answer(f"⏳ {len(ids)} ta foydalanuvchiga yuborilmoqda...")
    for uid in ids:
        try:
            await bot.copy_message(uid, m.chat.id, m.message_id)
            ok += 1
        except Exception:
            pass
        await asyncio.sleep(0.05)
    await m.answer(f"✅ Yuborildi: {ok}/{len(ids)}")


async def _change(m: Message, state: FSMContext, bot: Bot, sign):
    try:
        uid, amount = m.text.split()
        uid, amount = int(uid), int(amount)
        assert amount > 0
    except Exception:
        return await m.answer("❌ Format: <code>user_id miqdor</code>")
    await state.clear()
    u = await db.get_user(uid)
    if not u:
        return await m.answer("❌ Foydalanuvchi topilmadi.")
    if sign > 0:
        await db.add_diamonds(uid, amount)
    elif not await db.take_diamonds(uid, amount):
        return await m.answer("❌ Foydalanuvchida almaz yetarli emas.")
    u = await db.get_user(uid)
    await m.answer(f"✅ Bajarildi. Yangi balans: {u['diamonds']} 💎")
    try:
        await bot.send_message(uid, t(u["lang"], "bal_changed", d=sign * amount, b=u["diamonds"]))
    except Exception:
        pass


@router.message(A.give, F.text)
async def do_give(m: Message, state: FSMContext, bot: Bot):
    await _change(m, state, bot, +1)


@router.message(A.take, F.text)
async def do_take(m: Message, state: FSMContext, bot: Bot):
    await _change(m, state, bot, -1)


@router.message(A.ban, F.text)
async def do_ban(m: Message, state: FSMContext):
    if not m.text.strip().isdigit():
        return await m.answer("❌ Faqat user_id (son).")
    await state.clear()
    ok = await db.set_banned(int(m.text), True)
    await m.answer("🚫 Ban qilindi." if ok else "❌ Foydalanuvchi topilmadi.")


@router.message(A.unban, F.text)
async def do_unban(m: Message, state: FSMContext):
    if not m.text.strip().isdigit():
        return await m.answer("❌ Faqat user_id (son).")
    await state.clear()
    ok = await db.set_banned(int(m.text), False)
    await m.answer("✅ Bandan chiqarildi." if ok else "❌ Foydalanuvchi topilmadi.")


async def _price(m: Message, state: FSMContext, key):
    if not m.text.strip().isdigit() or int(m.text) <= 0:
        return await m.answer("❌ Faqat musbat son.")
    await state.clear()
    await db.set_setting(key, int(m.text))
    await m.answer(f"✅ Saqlandi: {int(m.text)} UZS")


@router.message(A.buy_price, F.text)
async def do_buy_price(m: Message, state: FSMContext):
    await _price(m, state, "buy_price")


@router.message(A.sell_price, F.text)
async def do_sell_price(m: Message, state: FSMContext):
    await _price(m, state, "sell_price")


@router.message(A.card, F.text)
async def do_card(m: Message, state: FSMContext):
    await state.clear()
    await db.set_setting("card", m.text.strip())
    await m.answer("✅ Karta saqlandi.")
