import time
import aiosqlite
from config import DB_PATH, DEFAULT_BUY_PRICE, DEFAULT_SELL_PRICE

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, name TEXT, lang TEXT DEFAULT 'uz',
  diamonds INTEGER DEFAULT 0, games INTEGER DEFAULT 0, wins INTEGER DEFAULT 0,
  banned INTEGER DEFAULT 0, joined INTEGER);
CREATE TABLE IF NOT EXISTS orders(
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, kind TEXT,
  amount INTEGER, total INTEGER, details TEXT,
  status TEXT DEFAULT 'pending', created INTEGER);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
"""


async def _exec(sql, args=()):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(sql, args)
        await db.commit()
        return cur.rowcount, cur.lastrowid


async def _one(sql, args=()):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(sql, args)
        r = await cur.fetchone()
        return dict(r) if r else None


async def _all(sql, args=()):
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        cur = await db.execute(sql, args)
        return [dict(r) for r in await cur.fetchall()]


async def init():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript(SCHEMA)
        await db.commit()
    defaults = (("buy_price", DEFAULT_BUY_PRICE), ("sell_price", DEFAULT_SELL_PRICE),
                ("card", "Karta raqami hali kiritilmagan"))
    for k, v in defaults:
        if await get_setting(k) is None:
            await set_setting(k, v)


# ---- settings
async def get_setting(key):
    r = await _one("SELECT value FROM settings WHERE key=?", (key,))
    return r["value"] if r else None


async def set_setting(key, value):
    await _exec("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", (key, str(value)))


# ---- users
async def get_user(uid):
    return await _one("SELECT * FROM users WHERE id=?", (uid,))


async def add_user(uid, name):
    await _exec("INSERT OR IGNORE INTO users(id,name,joined) VALUES(?,?,?)", (uid, name, int(time.time())))
    await _exec("UPDATE users SET name=? WHERE id=?", (name, uid))


async def get_lang(uid):
    u = await get_user(uid)
    return u["lang"] if u else "uz"


async def set_lang(uid, lang):
    await _exec("UPDATE users SET lang=? WHERE id=?", (lang, uid))


async def add_diamonds(uid, n):
    rc, _ = await _exec("UPDATE users SET diamonds=diamonds+? WHERE id=?", (n, uid))
    return rc > 0


async def take_diamonds(uid, n):
    rc, _ = await _exec("UPDATE users SET diamonds=diamonds-? WHERE id=? AND diamonds>=?", (n, uid, n))
    return rc > 0


async def set_banned(uid, flag):
    rc, _ = await _exec("UPDATE users SET banned=? WHERE id=?", (int(flag), uid))
    return rc > 0


async def all_user_ids():
    return [r["id"] for r in await _all("SELECT id FROM users WHERE banned=0")]


async def game_result(uid, won, diamonds):
    await _exec("UPDATE users SET games=games+1, wins=wins+?, diamonds=diamonds+? WHERE id=?",
                (int(won), diamonds, uid))


async def stats():
    u = await _one("SELECT COUNT(*) c, COALESCE(SUM(diamonds),0) d, COALESCE(SUM(games),0) g, "
                   "COALESCE(SUM(banned),0) b FROM users")
    o = await _one("SELECT COUNT(*) c FROM orders WHERE status='pending'")
    return u, o["c"]


# ---- orders
async def create_order(uid, kind, amount, total, details):
    _, oid = await _exec("INSERT INTO orders(user_id,kind,amount,total,details,created) VALUES(?,?,?,?,?,?)",
                         (uid, kind, amount, total, details, int(time.time())))
    return oid


async def get_order(oid):
    return await _one("SELECT * FROM orders WHERE id=?", (oid,))


async def claim_order(oid, status):
    """Atomik: faqat 'pending' buyurtmani bir marta qayta ishlaydi."""
    rc, _ = await _exec("UPDATE orders SET status=? WHERE id=? AND status='pending'", (status, oid))
    return rc > 0


async def pending_orders(limit=10):
    return await _all("SELECT * FROM orders WHERE status='pending' ORDER BY id LIMIT ?", (limit,))
