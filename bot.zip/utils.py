import logging
from html import escape as esc  # noqa: F401
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from config import ADMIN_IDS


def order_kb(oid):
    return InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="✅ Tasdiqlash", callback_data=f"ord:ok:{oid}"),
        InlineKeyboardButton(text="❌ Rad etish", callback_data=f"ord:no:{oid}"),
    ]])


async def notify_admins(bot, text, photo=None, kb=None):
    for aid in ADMIN_IDS:
        try:
            if photo:
                await bot.send_photo(aid, photo, caption=text, reply_markup=kb)
            else:
                await bot.send_message(aid, text, reply_markup=kb)
        except Exception as e:
            logging.warning("Admin %s ga yuborib bo'lmadi: %s", aid, e)
