import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMIN_IDS = [int(x) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip()]
DB_PATH = os.getenv("DB_PATH", "mafia.db")

MIN_PLAYERS = 4
MAX_PLAYERS = 20
NIGHT_SECONDS = 45
DAY_SECONDS = 60
VOTE_SECONDS = 45
WIN_DIAMONDS = 1          # g'oliblarga beriladigan almaz
DEFAULT_BUY_PRICE = 1000  # 1 almaz sotib olish narxi (UZS)
DEFAULT_SELL_PRICE = 700  # 1 almaz sotish narxi (UZS)
