MAFIA BAKU BOT (aiogram 3)

1) pip install -r requirements.txt
2) .env faylida BOT_TOKEN va ADMIN_IDS to'g'ri ekanini tekshiring
3) python main.py

Admin: /admin (shaxsiy chatda)
Guruhda: botni qo'shing (Admin qiling), /game
